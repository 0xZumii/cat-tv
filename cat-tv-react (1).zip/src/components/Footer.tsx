export function Footer() {
  return (
    <footer className="text-center py-10 px-6 text-text-soft text-sm">
      <p>Built with 💛 for cats everywhere</p>
    </footer>
  );
}
